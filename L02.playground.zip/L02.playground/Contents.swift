//: Playground - noun: a place where people can play

import UIKit
import PlaygroundSupport
let  x=2;
let y=14;
print(x+y);
for i in 1...100{
    print(i);
}

var str = "Hello, playground"
